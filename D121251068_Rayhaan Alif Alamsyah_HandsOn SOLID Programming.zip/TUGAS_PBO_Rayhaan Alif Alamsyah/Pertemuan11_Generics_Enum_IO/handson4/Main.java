package handson4;

public class Main {
    public static void main(String[] args) {
        Pair<Integer, String> pair1 = new Pair<>(101, "Mahasiswa Informatika");
        System.out.println("=== Pair 1 (Sebelum Swap) ===");
        pair1.showTypes();

        Pair<String, Integer> swappedPair1 = pair1.swap();
        System.out.println("=== Pair 1 (Sesudah Swap) ===");
        swappedPair1.showTypes();

        System.out.println();

        Pair<Double, Boolean> pair2 = new Pair<>(3.92, true);
        System.out.println("=== Pair 2 (Sebelum Swap) ===");
        pair2.showTypes();

        Pair<Boolean, Double> swappedPair2 = pair2.swap();
        System.out.println("=== Pair 2 (Sesudah Swap) ===");
        swappedPair2.showTypes();
    }
}
