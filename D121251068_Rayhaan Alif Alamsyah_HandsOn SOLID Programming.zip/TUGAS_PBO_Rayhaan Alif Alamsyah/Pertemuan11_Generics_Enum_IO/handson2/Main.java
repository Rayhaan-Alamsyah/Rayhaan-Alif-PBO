package handson2;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Daftar Tipe Akun, Kode Internal, dan Suku Bunga ===");
        for (AccountType type : AccountType.values()) {
            System.out.printf("Nama: %-10s | Kode: %-4s | Suku Bunga: %.2f%%%n",
                    type.name(), type.getCode(), type.getInterestRate());
        }
    }
}
