package handson6;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // 1. Demonstrasi deteksi jika file tidak ditemukan
        Path missingPath = Paths.get("file_tidak_ada.txt");
        if (Files.notExists(missingPath)) {
            System.out.println("[Peringatan] File '" + missingPath + "' tidak ditemukan!\n");
        }

        // 2. Membaca file employees.txt, simpan ke ArrayList<String>, lalu tulis ke copy_employees.txt
        Path sourcePath = Paths.get("employees.txt");
        Path copyPath = Paths.get("copy_employees.txt");

        if (Files.notExists(sourcePath)) {
            System.out.println("[Error] File '" + sourcePath.toAbsolutePath() + "' tidak ditemukan.");
            System.out.println("Pastikan file employees.txt berada di folder root project.");
            return;
        }

        ArrayList<String> employeeList = new ArrayList<>();

        try (BufferedReader br = Files.newBufferedReader(sourcePath, StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                employeeList.add(line);
            }

            System.out.println("=== Isi File employees.txt (Disimpan di ArrayList) ===");
            for (String emp : employeeList) {
                System.out.println(emp);
            }

            // Menuliskan isi ArrayList ke file baru copy_employees.txt
            Files.write(copyPath, employeeList, StandardCharsets.UTF_8);
            System.out.println("\nBerhasil menyalin " + employeeList.size()
                    + " baris data ke '" + copyPath + "'.");

        } catch (IOException e) {
            System.out.println("Terjadi kesalahan I/O: " + e.getMessage());
        }
    }
}
