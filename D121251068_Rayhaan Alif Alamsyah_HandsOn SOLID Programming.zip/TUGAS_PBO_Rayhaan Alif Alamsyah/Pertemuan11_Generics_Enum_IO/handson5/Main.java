package handson5;

public class Main {
    public static void main(String[] args) {
        System.out.println("Integer (5 == 5)          : " + CompareUtil.isEqual(5, 5));
        System.out.println("String (Hello == World)   : " + CompareUtil.isEqual("Hello", "World"));

        // Test case tambahan untuk Double dan Character
        System.out.println("Double (3.14 == 3.14)     : " + CompareUtil.isEqual(3.14, 3.14));
        System.out.println("Double (3.14 == 2.71)     : " + CompareUtil.isEqual(3.14, 2.71));
        System.out.println("Character ('A' == 'A')    : " + CompareUtil.isEqual('A', 'A'));
        System.out.println("Character ('A' == 'B')    : " + CompareUtil.isEqual('A', 'B'));
    }
}
