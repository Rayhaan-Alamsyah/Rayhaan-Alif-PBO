package handson3;

public class Main {
    public static void main(String[] args) {
        Cell<Integer> integerCell = new Cell<>();
        integerCell.setValue(2026);
        integerCell.displayType();

        Cell<String> stringCell = new Cell<>();
        stringCell.setValue("Pemrograman Berorientasi Objek");
        stringCell.displayType();

        // Contoh type safety: baris di bawah akan error saat compile-time jika diaktifkan
        // integerCell.setValue("Bukan Angka");
    }
}
