package handson8;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Path outputPath = Paths.get("user_input.txt");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        System.out.println("=== Pencatat Input Pengguna ===");
        System.out.println("Ketik teks apa saja lalu tekan Enter. Ketik 'exit' untuk berhenti.\n");

        try (Scanner sc = new Scanner(System.in);
             BufferedWriter bw = Files.newBufferedWriter(outputPath, StandardCharsets.UTF_8)) {

            while (true) {
                System.out.print("Enter text: ");
                String text = sc.nextLine();

                if (text.equalsIgnoreCase("exit")) {
                    System.out.println("Program selesai. Semua input tersimpan di '" + outputPath + "'.");
                    break;
                }

                String timestamp = LocalDateTime.now().format(formatter);
                bw.write("[" + timestamp + "] " + text);
                bw.newLine();
                bw.flush();
                System.out.println("Saved with timestamp!");
            }

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
