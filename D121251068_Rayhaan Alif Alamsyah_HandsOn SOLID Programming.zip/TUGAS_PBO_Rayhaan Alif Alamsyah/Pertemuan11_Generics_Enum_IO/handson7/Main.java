package handson7;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class Main {
    private static final Path LOG_PATH = Paths.get("log.txt");
    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private static void writeLog(String message) {
        String timestamp = LocalDateTime.now().format(FORMATTER);
        String logEntry = "[" + timestamp + "] " + message + System.lineSeparator();
        try {
            Files.writeString(LOG_PATH, logEntry, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.out.println("Gagal menulis log: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        Path source = Paths.get("report.txt");
        Path backup = Paths.get("backup/report.txt");

        try {
            // Membuat file laporan awal
            Files.write(source, List.of("Report Generated", "Status: OK"), StandardCharsets.UTF_8);
            writeLog("INFO: File sumber '" + source + "' berhasil dibuat.");

            // Pengecekan keberadaan file sebelum menyalin
            if (Files.exists(source)) {
                if (backup.getParent() != null && Files.notExists(backup.getParent())) {
                    Files.createDirectories(backup.getParent());
                }
                Files.copy(source, backup, StandardCopyOption.REPLACE_EXISTING);
                String successMsg = "SUCCESS: File '" + source + "' berhasil disalin ke '" + backup + "'.";
                System.out.println(successMsg);
                writeLog(successMsg);
            } else {
                String warnMsg = "FAILED: File sumber '" + source + "' tidak ditemukan, penyalinan dibatalkan.";
                System.out.println(warnMsg);
                writeLog(warnMsg);
            }
        } catch (IOException e) {
            String errorMsg = "ERROR: Terjadi kesalahan saat operasi file - " + e.getMessage();
            System.out.println(errorMsg);
            writeLog(errorMsg);
        }
    }
}
