package handson9;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void serialize(String fileName, List<Employee> employees) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(employees);
            System.out.println("Serialized " + employees.size() + " objek Employee ke '" + fileName + "'.");
        } catch (IOException ex) {
            System.out.println("Error serialization: " + ex.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public static List<Employee> deserialize(String fileName) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            return (List<Employee>) ois.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error deserialization: " + ex.getMessage());
            return new ArrayList<>();
        }
    }

    public static void main(String[] args) {
        String fileName = "emp.ser";

        List<Employee> employeeList = List.of(
                new Employee("John", 30, "Engineering"),
                new Employee("Aulia", 24, "Product Design"),
                new Employee("Rizky", 28, "Data Science")
        );

        // Proses Serialization
        serialize(fileName, employeeList);

        // Proses Deserialization menggunakan method deserialize()
        System.out.println("\n=== Hasil Deserialization dari '" + fileName + "' ===");
        List<Employee> restoredEmployees = deserialize(fileName);
        for (Employee emp : restoredEmployees) {
            System.out.println(emp);
        }
    }
}
