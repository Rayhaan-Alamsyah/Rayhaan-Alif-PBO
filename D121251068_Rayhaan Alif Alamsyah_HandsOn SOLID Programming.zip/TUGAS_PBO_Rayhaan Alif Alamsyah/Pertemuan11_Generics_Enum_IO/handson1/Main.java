package handson1;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Daftar Semua Tipe AccountType ===");
        for (AccountType type : AccountType.values()) {
            System.out.println("- " + type);
        }

        System.out.println("\n=== Pengujian Objek Account ===");
        Account acc1 = new Account("1001-01", AccountType.SAVINGS);
        Account acc2 = new Account("1001-02", AccountType.CREDIT);
        Account acc3 = new Account("1001-03", AccountType.DEPOSIT);

        acc1.displayInfo();
        acc2.displayInfo();
        acc3.displayInfo();
    }
}
