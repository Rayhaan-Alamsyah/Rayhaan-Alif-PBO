package handson1;

public enum AccountType {
    SAVINGS("Savings Account - Rekening Tabungan Harian"),
    CREDIT("Credit Account - Rekening Fasilitas Kredit"),
    DEPOSIT("Deposit Account - Rekening Simpanan Berjangka");

    private final String description;

    AccountType(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return name() + " (" + description + ")";
    }
}
