package latihan2;

public class Main {
    public static void main(String[] args) {
        Student mahasiswa = new Student("Andi", 80, 85, 90);

        GradeCalculator calculator = new GradeCalculator();
        GradeReportPrinter printer = new GradeReportPrinter();
        GradeRepository repository = new GradeRepository();

        double nilaiAkhir = calculator.hitungNilaiAkhir(mahasiswa);
        printer.cetakLaporan(mahasiswa.getNama(), nilaiAkhir);
        repository.simpanDatabase(mahasiswa.getNama(), nilaiAkhir);
    }
}
