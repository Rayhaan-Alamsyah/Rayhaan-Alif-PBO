package latihan1;

public class Main {
    public static void main(String[] args) {
        NotificationService service = new NotificationService();

        // Pengiriman individual sesuai abstraksi
        service.sendSingle(new EmailNotification(), "Halo, ini email test!");
        service.sendSingle(new SMSNotification(), "Ini SMS test!");
        service.sendSingle(new WhatsAppNotification(), "Ini pesan WhatsApp test!");

        System.out.println();
        System.out.println("--- Ekstensi Kanal Baru (OCP) & Broadcast Multi-Platform ---");
        service.addChannel(new EmailNotification());
        service.addChannel(new SMSNotification());
        service.addChannel(new WhatsAppNotification());
        service.addChannel(new TelegramNotification());

        service.sendToAll("Pengumuman: Jadwal praktikum PBO dimulai pukul 08.00 WITA.");
    }
}
