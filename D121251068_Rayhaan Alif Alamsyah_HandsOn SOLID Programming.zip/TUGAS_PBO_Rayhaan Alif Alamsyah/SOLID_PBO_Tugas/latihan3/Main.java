package latihan3;

public class Main {
    public static void main(String[] args) {
        MobilListrik mobilListrik = new MobilListrik("Hyundai Ioniq 5");
        mobilListrik.startEngine();
        mobilListrik.isiBaterai();
        mobilListrik.bergerak();

        System.out.println();

        MobilBensin mobilBensin = new MobilBensin("Toyota Avanza");
        mobilBensin.startEngine();
        mobilBensin.isiBahanBakar();
        mobilBensin.bergerak();

        System.out.println();

        Sepeda sepeda = new Sepeda("Polygon Strattos");
        sepeda.bergerak();

        System.out.println();

        MobilHybrid mobilHybrid = new MobilHybrid("Toyota Kijang Innova Zenix Hybrid");
        mobilHybrid.startEngine();
        mobilHybrid.isiBahanBakar();
        mobilHybrid.isiBaterai();
        mobilHybrid.bergerak();
    }
}
