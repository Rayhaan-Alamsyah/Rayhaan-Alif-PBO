# Tugas Praktikum PBO - Penerapan Prinsip SOLID

Repositori ini berisi implementasi hasil refactoring kode menggunakan prinsip **SOLID** dalam bahasa Java untuk tiga studi kasus latihan:

1. **Latihan 1 (`latihan1/`) - Notifikasi Multi-Platform**
   - Prinsip yang diterapkan: **SRP, OCP, ISP, DIP**
   - Memisahkan kanal notifikasi (`EmailNotification`, `SMSNotification`, `WhatsAppNotification`, `TelegramNotification`) melalui interface `NotificationChannel`.

2. **Latihan 2 (`latihan2/`) - Penilaian Mahasiswa**
   - Prinsip yang diterapkan: **SRP (Single Responsibility Principle)**
   - Memisahkan tanggung jawab kelas `StudentGrader` menjadi `Student`, `GradeCalculator`, `GradeReportPrinter`, dan `GradeRepository`.

3. **Latihan 3 (`latihan3/`) - Smart Vehicle**
   - Prinsip yang diterapkan: **ISP (Interface Segregation Principle) & OCP (Open-Closed Principle)**
   - Memecah kapabilitas kendaraan menjadi `EngineStartable`, `FuelRefillable`, dan `BatteryChargeable` di atas kelas abstrak `Vehicle`.

## Cara Menjalankan di VS Code
1. Ekstrak file ZIP ini dan buka foldernya di **Visual Studio Code**.
2. Pastikan **Extension Pack for Java** sudah terpasang.
3. Buka file `Main.java` di masing-masing folder (`latihan1`, `latihan2`, `latihan3`) lalu klik **Run** di atas method `main`.
